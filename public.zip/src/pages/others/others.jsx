import React from 'react'

const Others = () => {
  return (
    <div className='grid place-content-center w-full h-screen'>Under Maintanance</div>
  )
}

export default Others