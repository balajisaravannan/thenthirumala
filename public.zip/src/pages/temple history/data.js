
export const contentOneDataEn = [ 
 {name : 'Narada needed some help to fulfill his mission. Then he went to the banks of the river Ganges, where many sages were performing yagya. The sages could not decide who deserved the fruits of their sacrifice. Sage Bhrigu decided to solve the problem by examining the Hindu trinity - Brahma the creator, Vishnu the preserver and Shiva the destroyer.'}, 
 {name : 'The sages could not decide who deserved the fruits of their sacrifice. Sage Bhrigu decided to solve the problem by examining the Hindu trinity - Brahma the creator, Vishnu the preserver and Shiva the destroyer.'}, 
 {name : 'Narada needed some help to fulfill his mission. Then he went to the banks of the river Ganga where many sages were performing yagya. The sages could not decide who deserved the fruits of their sacrifice. Sage Bhrigu decided to solve the problem by examining the Hindu trinity - Brahma the creator, Vishnu the preserver and Shiva the destroyer.'}, 
 {name : 'The sages could not decide who deserved the fruits of their sacrifice. Sage Bhrigu decided to solve the problem by examining the Hindu trinity - Brahma the creator, Vishnu the preserver and Shiva the destroyer.'}
]

export const contentOneDataTn = [ 
 {name : 'நாரதரின் பணியை நிறைவேற்ற சில உதவி தேவைப்பட்டது. பிறகு பல முனிவர்கள் யாகம் செய்து கொண்டிருந்த கங்கைக் கரைக்குச் சென்றார். தங்களின் தியாகத்தின் பலனுக்கு யார் தகுதியானவர்கள் என்பதை முனிவர்களால் தீர்மானிக்க முடியவில்லை. பிருகு முனிவர் இந்து மும்மூர்த்திகளை ஆராய்ந்து பிரச்சினையை தீர்க்க முடிவு செய்தார் - பிரம்மா படைப்பாளி, விஷ்ணு காப்பவர் மற்றும் சிவன் அழிப்பவர்.'}, 
 {name : 'தங்களின் தியாகத்தின் பலனுக்கு யார் தகுதியானவர்கள் என்பதை முனிவர்களால் தீர்மானிக்க முடியவில்லை. பிருகு முனிவர் இந்து மும்மூர்த்திகளை ஆராய்ந்து பிரச்சினையை தீர்க்க முடிவு செய்தார் - பிரம்மா படைப்பாளி, விஷ்ணு காப்பவர் மற்றும் சிவன் அழிப்பவர்.'}, 
 {name : 'நாரதரின் பணியை நிறைவேற்ற சில உதவி தேவைப்பட்டது. பிறகு பல முனிவர்கள் யாகம் செய்து கொண்டிருந்த கங்கைக் கரைக்குச் சென்றார். தங்களின் தியாகத்தின் பலனுக்கு யார் தகுதியானவர்கள் என்பதை முனிவர்களால் தீர்மானிக்க முடியவில்லை. பிருகு முனிவர் இந்து மும்மூர்த்திகளை ஆராய்ந்து பிரச்சினையை தீர்க்க முடிவு செய்தார் - பிரம்மா படைப்பாளி, விஷ்ணு காப்பவர் மற்றும் சிவன் அழிப்பவர்.'}, 
 {name : 'தங்களின் தியாகத்தின் பலனுக்கு யார் தகுதியானவர்கள் என்பதை முனிவர்களால் தீர்மானிக்க முடியவில்லை. பிருகு முனிவர் இந்து மும்மூர்த்திகளை ஆராய்ந்து பிரச்சினையை தீர்க்க முடிவு செய்தார் - பிரம்மா படைப்பாளி, விஷ்ணு காப்பவர் மற்றும் சிவன் அழிப்பவர்.'}
]